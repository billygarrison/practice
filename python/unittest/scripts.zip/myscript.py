from myfunctions import add_ten, subtract_ten, multiply_ten, divide_ten


print("6 + 10 = " + str(add_ten(6)))
print("6 - 10 = " + str(subtract_ten(6)))
print("6 * 10 = " + str(multiply_ten(6)))
print("6 / 10 = " + str(divide_ten(6)))
