# --- MATH --- #


def add_ten(x):
    return float(x + 10)


def subtract_ten(x):
    return x - 10


def multiply_ten(x):
    return x * 10


def divide_ten(x):
    return 20 / 10


# --- STRINGS --- #


def concatenate(x, y):
    return x + y


def r_paste(x, y):
    return x + " " + y
